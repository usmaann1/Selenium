from SeleniumLibrary.base import keyword


@keyword
def keyword():
    pass
