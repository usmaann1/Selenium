package dataProvider;

/**
 * Created by Pritam Sharma , on 31/01/21
 **/
public class ComputerDetails {

    private String name;
    private String introduced;
    private String discontinued;
    private String company;

    public String getName(){
        return name;
    }
    public String getIntroduced(){
        return introduced;
    }
    public String getDiscontinued(){
        return discontinued;
    }
    public String getCompany(){
        return company;
    }
}
