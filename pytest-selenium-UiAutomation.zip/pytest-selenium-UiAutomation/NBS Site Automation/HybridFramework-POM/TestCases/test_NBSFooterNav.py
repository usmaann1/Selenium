from idlelib import browser

import pytest

import time

from concurrent.futures import thread

import self as self

import username as username

from selenium import webdriver

from selenium.webdriver import ActionChains

from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager import driver

from webdriver_manager.chrome import ChromeDriverManager

import unittest

@pytest.mark.usefixtures("setup")
class BottomButtonsNav(unittest.TestCase):
    def test_Application_and_DBMigration(self):

       self.driver.find_element_by_xpath("//li[@id='menu-item-3998']//span[@class='menu-text'][normalize-space()='Application and DB Migration']").click()
       time.sleep(2)
       self.driver.maximize.window()
       try:                                                           # Pass/Fail Cases
           assert 'Application and Database Migration | AWS Premier Consulting Partner' == driver.title
           print('Test Passed')
       except Exception as e:
           print('Test Failed', format(e))





# fgh = TestAbc
# fgh.test_abc(self)