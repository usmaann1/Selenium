import time

from selenium import webdriver

from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager


opt = Options()
opt.headless = True                                                   # For Headless Display
driver = webdriver.Chrome(ChromeDriverManager().install(), chrome_options=opt)

Username = "usmaann10@gmail.com"
Password = "987654"

driver.get(
            "https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1634106041&rver=7.0.6737.0&wp=MBI_SSL&wreply"
            "=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d7e2f6ef9-47ad-aa5f-85e2-4108119782ab"
            "&id=292841&aadredir=1&whr=gmail.com&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015")
time.sleep(4)
print(driver.title)

# For reporting i run the following command in python terminal:
# test_file_Path="path of your test file"
# reportName="Write title of your html file"
# pytest [test_file_Path] -v --html =./[reportName].html