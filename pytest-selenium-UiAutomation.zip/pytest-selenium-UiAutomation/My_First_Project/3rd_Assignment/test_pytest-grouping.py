import pytest

import time

from concurrent.futures import thread

import username as username

from selenium import webdriver

from selenium.webdriver import ActionChains

from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager import driver

from webdriver_manager.chrome import ChromeDriverManager



class TestLabel():
 def test_labelonEmail(self):

       driver = webdriver.Chrome(ChromeDriverManager().install())

       Username = "usmaann10@gmail.com"
       Password = "987654"

       driver.get("https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1634106041&rver=7.0.6737.0&wp=MBI_SSL&wreply"
           "=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d7e2f6ef9-47ad-aa5f-85e2-4108119782ab"
           "&id=292841&aadredir=1&whr=gmail.com&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015")
       time.sleep(2)
       driver.maximize_window()
       username_input = driver.find_element_by_xpath("//input[@id='i0116']")        # Input field
       username_input.send_keys(Username)
       time.sleep(2)

       driver.find_element_by_xpath("//input[@id='idSIButton9']").click()

       password_input = driver.find_element_by_xpath("//input[@id='i0118']")       # Password Field
       password_input.send_keys(Password)
       time.sleep(2)

       driver.find_element_by_xpath("//input[@id='idSIButton9']").click()          # Signin button
       time.sleep(2)

       driver.find_element_by_css_selector("#idBtn_Back").click()
       time.sleep(2)

       driver.find_element_by_css_selector("div[role='tree'] div div[draggable='true'] div[title='Sent Items'] span[class='_3fLh9Wjn6GR68OwcUckdM0 _3kaE-lp56xiPtiBK5bJWgr']").click()
       time.sleep(2)

       mailbutton = driver.find_element_by_css_selector("._3uDKZZbosbt_MutV5HLmnr._3AhvfFCmTCMeJ_TiEpVcdH")
       actionabx = ActionChains(driver)
       actionabx.move_to_element(mailbutton).perform()
       time.sleep(2)
       driver.find_element_by_xpath("(//div[@aria-label='Select a conversation'])[1]").click()
       time.sleep(6)

       driver.find_element_by_xpath("//button[@name='Categorize']//span[@class='ms-Button-flexContainer flexContainer-47']").click()
       time.sleep(2)
       driver.find_element_by_css_selector("div[title='Green category'] span[class='_3pwqsmzAZJwP9Ce6jlhgMZ']").click()

       dauto = TestLabel
       dauto.test_labelonEmail()
