import time

from concurrent.futures import thread

from selenium import webdriver

from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support import expected_conditions as EC

from webdriver_manager.chrome import ChromeDriverManager

driver = webdriver.Chrome(ChromeDriverManager().install())


Username = "usman.allaudin@gmaill.com"
Password = "9876"

driver.get("https://auth.testproject.io/auth/realms/TP/protocol/openid-connect/auth?client_id=tp.app&redirect_uri"
           "=https%3A%2F%2Fapp.testproject.io%2Fcallback.html&response_type=id_token%20token&scope=openid%20profile"
           "&state=e0c67c02275944d985d6e3204d856e5f&nonce=049f651e27864e0fbeb6f48a14f8ab01/")
time.sleep(4)
driver.maximize_window()
username_input = driver.find_element_by_xpath("//input[@id='username']")               # Username Textbox
username_input.send_keys(Username)
time.sleep(4)


password_input = driver.find_element_by_xpath("//input[@id='password']")              # Password Textbox
password_input.send_keys(Password)
time.sleep(4)

driver.find_element_by_xpath("//input[@id='tp-sign-in']").click()                      # Signin Button
time.sleep(4)

try:                                                                 # Pass/Fail Cases
    assert 'TestProject - Login' in driver.title
    print('Test Passed')
except Exception as e:
    print('Test Failed', format(e))

driver.close()
