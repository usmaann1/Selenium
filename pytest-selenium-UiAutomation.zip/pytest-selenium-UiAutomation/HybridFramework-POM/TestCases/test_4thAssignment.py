
import pytest

import time

from concurrent.futures import thread

import self as self

import username as username

from selenium import webdriver

from selenium.webdriver import ActionChains

from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support import expected_conditions as EC

from webdriver_manager.chrome import ChromeDriverManager

@pytest.mark.usefixtures("setup")
class Testabc():
 def test_abc(self):

            Username = "usmaann10@gmail.com"
            Password = "987654"
            Email = "usman.allaudin@northbaysolutions.net"                # Reciever email address
            username_input = self.driver.find_element_by_xpath("//input[@id='i0116']")        # username input
            username_input.send_keys(Username)
            time.sleep(2)

            self.driver.find_element_by_xpath("//input[@id='idSIButton9']").click()

            password_input = self.driver.find_element_by_xpath("//input[@id='i0118']")      # password input
            password_input.send_keys(Password)
            time.sleep(2)

            self.driver.find_element_by_xpath("//input[@id='idSIButton9']").click()         # signin button
            time.sleep(2)

            self.driver.find_element_by_css_selector("#idBtn_Back").click()          # Compose mail button
            time.sleep(2)

            self.driver.find_element_by_css_selector("#id__7").click()             # Reciever email text field
            time.sleep(8)

            self.driver.find_element_by_css_selector("input[aria-label='To']").send_keys(Email)
            time.sleep(8)

                                                                                         # Attach buttons
            self.driver.find_element_by_css_selector(".ms-Icon.root-32.css-42.ms-Button-menuIcon._237AVRGSBNqSjtdVoihVAk.menuIcon-58[data-icon-name='ChevronDown']").click()
            time.sleep(8)


            upload_file = self.driver.find_element_by_xpath("//span[normalize-space()='Browse this computer']").click()
            time.sleep(5)
            upload_file.send_keys("C://Users/usman.allaudin/Downloads/apple")      # select image from comp
            time.sleep(4)

            # Send Button
            self.driver.find_element_by_css_selector("button[title='Send (Ctrl+Enter)']").click()
            time.sleep(8)



# fgh = TestAbc
# fgh.test_abc(self)