import pytest

import time

from concurrent.futures import thread

import username as username

from selenium import webdriver

from selenium.webdriver import ActionChains

from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support import expected_conditions as EC

from webdriver_manager.chrome import ChromeDriverManager

@pytest.fixture(scope="class")
def setup(request):

    driver = webdriver.Chrome(ChromeDriverManager().install())
    wait = WebDriverWait(driver, 10)

    driver.get("https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1634106041&rver=7.0.6737.0&wp=MBI_SSL&wreply"
               "=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d7e2f6ef9-47ad-aa5f-85e2-4108119782ab"
               "&id=292841&aadredir=1&whr=gmail.com&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015")
    time.sleep(2)
    driver.maximize_window()
    request.cls.driver = driver
    request.cls.wait = wait