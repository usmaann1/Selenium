from selenium.webdriver import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

""" 
Parent class for all the pages
This class is used to initialize the required functions of the web-driver
"""

class BasePage:
    def __init__(self,driver):
        self.driver=driver

    def do_click(self,by_locators):
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locators)).click()

    def do_send_keys(self, by_locators,text):
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locators)).send_keys(text)

    def do_clear_feild(self, by_locators):
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locators)).clear()

    def do_element_text(self, by_locators):
        element=WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locators))
        return element.text

    def read_only(self,by_locators):
        element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locators))
        return bool(element.get_attribute("readonly"))

    def is_visible(self, by_locators):
        element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locators))
        return bool(element)

    def get_title(self):
        "  commented the web driver wait line because selected website does not have title element in page "
        #WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(title))
        return self.driver.title