from selenium.webdriver.common.by import  By
from Pages.BasePage import BasePage
from Configs.config import TestData
"""
This class contains all the locators and method of the Login Page 
"""
class MainPage(BasePage):

    MAIN_PAGE=(By.XPATH, '//*[@id="wrapper"]/header[1]/div[1]/div[2]/div[1]/div[1]/a[1]/img[1]')
    """Constructor of the page class called"""

    def __init__(self, driver):
        super(MainPage, self).__init__(driver)
        self.driver.maximize_window()
        self.driver.get(TestData.WEBSITE_URI)

    "---Page Actions---"
    "Get page Title"
    def get_login_page_title(self):
        return self.get_title()

    def get_welcomePage(self):
        self.do_click(self.MAIN_PAGE)