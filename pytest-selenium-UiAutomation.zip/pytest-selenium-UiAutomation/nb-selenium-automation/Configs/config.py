#Data class contains all data elements
class TestData:
    FIREFOX_E_PATH='C:\Browser Drivers\geckodriver.exe'
    CHROME_E_PATH='C:\Browser Drivers\chromedriver.exe'
    WEBSITE_URI='https://northbaysolutions.com/'

    PAGE_TITLE='Northbay Solutions | AWS Premier Consulting Partner'
