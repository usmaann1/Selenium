from datetime import time

import pytest
from selenium import  webdriver
from selenium.webdriver.support.wait import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager
from concurrent.futures import thread
import username as username
from selenium.webdriver import ActionChains
from  Configs.config import TestData

# This method initialized and open the web-driver according to its params.
@pytest.fixture(params=["chrome"],scope='class')

def init_driver(request):
    if request.param=="chrome":
        option=webdriver.ChromeOptions()
        #set headless = True for headless execution
        option.headless=False
        web_driver=webdriver.Chrome(TestData.CHROME_E_PATH,options=option)
    if request.param == "firefox":
        option = webdriver.FirefoxOptions()
        #set headless = True for headless execution
        option.headless = True
        web_driver = webdriver.Firefox(TestData.FIREFOX_E_PATH,options=option)
    request.cls.driver=web_driver
    yield
    #web_driver.close()


