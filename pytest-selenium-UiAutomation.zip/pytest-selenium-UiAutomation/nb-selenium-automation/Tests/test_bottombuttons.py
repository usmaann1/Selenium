from idlelib import browser

import pytest

import time

from concurrent.futures import thread

import self as self

import username as username

from selenium import webdriver

from selenium.webdriver.common.action_chains import ActionChains

from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support import expected_conditions as EC

from webdriver_manager import driver

from webdriver_manager.chrome import ChromeDriverManager

import unittest
from Configs.config import TestData
from Pages.MainPage import MainPage
from Tests.test_base import BaseTest
import re

class Test_Login(BaseTest):
        def test_Application_and_DBMigration(self):                           #Test 1
            self.mainPage = MainPage(self.driver)
            element1 = self.driver.find_element_by_xpath("//li[@id='menu-item-3998']//span[@class='menu-text'][normalize-space()='Application and DB Migration']")
            time.sleep(2)
            element1.click()
            time.sleep(2)
                                                      # Pass/Fail Cases
            assert 'Application and Database Migration | AWS Premier Consulting Partner' == self.driver.title

        def test_Vmware_Cloud_on_AWS(self):                                  # Test2
            self.mainPage = MainPage(self.driver)
            element2 = self.driver.find_element_by_xpath("//li[@id='menu-item-4004']//span[@class='menu-text'][normalize-space()='VMware Cloud on AWS']")
            time.sleep(2)
            element2.click()
            time.sleep(2)

            assert 'Migrate VMware workloads on Aws | AWS Premier Consulting Partner' == self.driver.title


        def test_Windows_on_AWS(self):                                    # Test3
            self.mainPage = MainPage(self.driver)
            element3 = self.driver.find_element_by_xpath("//li[@id='menu-item-4005']//span[@class='menu-text'][normalize-space()='Windows on AWS']")
            time.sleep(2)
            element3.click()
            time.sleep(2)

            assert 'Migrate Windows to AWS | Microsoft on AWS | Northbay Solutions' == self.driver.title



        def test_SAP_on_AWS(self):                                   # Test4
            self.mainPage = MainPage(self.driver)
            element4 = self.driver.find_element_by_xpath("//li[@id='menu-item-9403']//span[@class='menu-text'][normalize-space()='SAP on AWS']")
            time.sleep(2)
            element4.click()
            time.sleep(2)

            assert 'Migrating SAP Systems and Workloads on AWS | SAP on AWS-Northbay Solutions' == self.driver.title



        def test_App_and_Data_Modern(self):                                   # Test5
            self.mainPage = MainPage(self.driver)
            element5 = self.driver.find_element_by_xpath("//li[@id='menu-item-3997']//span[@class='menu-text'][normalize-space()='Application and Data Modernization']")
            time.sleep(2)
            element5.click()
            time.sleep(2)

            assert 'Application and Data Modernization | Aws Premier Consulting Partner' == self.driver.title



        def test_Cloud_App_Development(self):                                   # Test6
            self.mainPage = MainPage(self.driver)
            element6 = self.driver.find_element_by_xpath("//li[@id='menu-item-3999']//span[@class='menu-text'][normalize-space()='Cloud Application Development']")
            time.sleep(2)
            element6.click()
            time.sleep(2)

            assert 'Cloud Application Development | Certified Professionals | Northbay' == self.driver.title




        def test_Devops_Enablement(self):                                   # Test7
            self.mainPage = MainPage(self.driver)
            element7 = self.driver.find_element_by_xpath("//li[@id='menu-item-4001']//span[@class='menu-text'][normalize-space()='DevOps Enablement']")
            time.sleep(2)
            element7.click()
            time.sleep(2)

            assert 'DevOps Enablement | Premier Consulting Partner | Northbay Solutions' == self.driver.title




        def test_Data_lake_Warehouse_Analytics(self):                                   # Test8
            self.mainPage = MainPage(self.driver)
            element8 = self.driver.find_element_by_xpath("//li[@id='menu-item-4000']//span[@class='menu-text'][normalize-space()='Data Lake, Data Warehouse and Analytics']")
            time.sleep(2)
            element8.click()
            time.sleep(2)

            assert 'Data Lake and Analytics | AWS Consulting Partner | Northbay Solutions' == self.driver.title



        def test_Machine_Learning_And_AI(self):                                   # Test9
            self.mainPage = MainPage(self.driver)
            element9 = self.driver.find_element_by_xpath("//li[@id='menu-item-4003']//span[@class='menu-text'][normalize-space()='Machine Learning & AI']")
            time.sleep(2)
            element9.click()
            time.sleep(2)

            assert 'Aws AI and Machine learning Service Provider | Northbay Solutions' == self.driver.title




        def test_Who_We_Are(self):                                   # Test10
            self.mainPage = MainPage(self.driver)
            element10 = self.driver.find_element_by_xpath("//li[@id='menu-item-6126']//span[@class='menu-text'][normalize-space()='Who we are']")
            time.sleep(2)
            element10.click()
            time.sleep(2)

            assert 'Northbay Solutions| who we are | AWS Partner' == self.driver.title





        def test_Our_Team(self):                                   # Test11
            self.mainPage = MainPage(self.driver)
            element11 = self.driver.find_element_by_xpath("//li[@id='menu-item-4780']//span[@class='menu-text'][normalize-space()='Our Team']")
            time.sleep(2)
            element11.click()
            time.sleep(2)

            assert 'Northbay Solutions| who we are | AWS Partner' == self.driver.title





        def test_Blog(self):                                   # Test12
            self.mainPage = MainPage(self.driver)
            element12 = self.driver.find_element_by_xpath("//li[@id='menu-item-6572']//span[@class='menu-text'][normalize-space()='Blog']")
            time.sleep(2)
            element12.click()
            time.sleep(2)

            assert 'Blogs | AWS Solutions | Application and Data Modernization' == self.driver.title





        def test_Case_Studies(self):                                   # Test13
            self.mainPage = MainPage(self.driver)
            element13 = self.driver.find_element_by_xpath("//li[@id='menu-item-6573']//span[@class='menu-text'][normalize-space()='Case Studies']")
            time.sleep(2)
            element13.click()
            time.sleep(2)

            assert 'Case Studies | AWS Premier Consulting Partner | Northbay Solutions' == self.driver.title




        def test_AWS(self):                                   # Test14
            self.mainPage = MainPage(self.driver)
            element14 = self.driver.find_element_by_xpath("//span[@class='menu-text'][normalize-space()='AWS']")
            time.sleep(2)
            element14.click()
            time.sleep(2)

            assert 'AWS Premier Consulting Partner| Northbay Solutions' == self.driver.title





        def test_SAP(self):                                   # Test15
            self.mainPage = MainPage(self.driver)
            element15 = self.driver.find_element_by_xpath("//span[@class='menu-text'][normalize-space()='SAP']")
            time.sleep(2)
            element15.click()
            time.sleep(2)

            assert 'SAP Consulting Partner | Northbay Solutions' == self.driver.title





        def test_CloudRail_IIOT(self):                                   # Test16
            self.mainPage = MainPage(self.driver)
            element16 = self.driver.find_element_by_xpath("//span[@class='menu-text'][normalize-space()='CloudRail-IIoT']")
            time.sleep(2)
            element16.click()
            time.sleep(2)

            assert 'CloudRail IIoT and AWS| Consulting Services by Northbay Solutions' == self.driver.title




        def test_Vmware(self):                                   # Test17
            self.mainPage = MainPage(self.driver)
            element17 = self.driver.find_element_by_xpath("//span[@class='menu-text'][normalize-space()='VMware']")
            time.sleep(2)
            element17.click()
            time.sleep(2)

            assert 'Vmware Workload on AWS Cloud | Best Consultant Vmware and AWS' == self.driver.title





        def test_Industry(self):                                   # Test18
            self.mainPage = MainPage(self.driver)
            element18 = self.driver.find_element_by_xpath("//a[contains(text(),'Industry')]")
            time.sleep(2)
            element18.click()
            time.sleep(2)

            assert 'Industry Solutions - NorthBay Solutions' == self.driver.title






        def test_Careers(self):                                   # Test19
            self.mainPage = MainPage(self.driver)
            element19 = self.driver.find_element_by_xpath("//div[@class='fusion-title title fusion-title-37 fusion-sep-none fusion-title-text fusion-title-size-one']//a[@class='awb-custom-text-color awb-custom-text-hover-color'][normalize-space()='Careers']")
            time.sleep(2)
            element19.click()
            time.sleep(2)

            assert 'Join Us | AWS Premier Consulting Partner |Jobs at NorthBay Solutions' == self.driver.title


