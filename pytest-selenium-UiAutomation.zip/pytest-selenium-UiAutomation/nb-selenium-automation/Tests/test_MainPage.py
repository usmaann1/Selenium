

from Configs.config import TestData
from Pages.MainPage import MainPage
from Tests.test_base import BaseTest
import re

class Test_Login(BaseTest):

    def test_main_page_title(self):
        self.mainPage=MainPage(self.driver)
        self.mainPage.get_welcomePage()
        title = self.mainPage.get_title()
        assert title==TestData.PAGE_TITLE
