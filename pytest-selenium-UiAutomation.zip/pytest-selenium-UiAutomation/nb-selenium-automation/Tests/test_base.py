import pytest
# This class is used to initialize the web driver using Fixtures in pytest
@pytest.mark.usefixtures("init_driver")
class BaseTest:
    pass